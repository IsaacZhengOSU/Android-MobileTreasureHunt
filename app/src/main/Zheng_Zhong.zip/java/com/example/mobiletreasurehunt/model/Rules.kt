/***********************
 * Assignment 5
 * Zhong Zheng
 * Oregon State University
 * CS 492
 */
package com.example.mobiletreasurehunt.model

import androidx.annotation.StringRes

data class Rules(
    @StringRes val stringResourceId1: Int,
)